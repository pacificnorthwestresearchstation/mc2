#!/bin/sh
#
# Run the 4 phases of MC2.
#
# "Starter Kit" for MC2. By John Kim, USDA Forest Service, jbkim@fs.fed.us. 2014.
#

./mc2 Test MAPSS.cmd
./mc2 Test EQ.cmd
./mc2 Test Spinup.cmd
./mc2 Test Hist.cmd
./mc2 Test Future.cmd
